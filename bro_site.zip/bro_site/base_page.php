<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" type="text/css"
	  href="css/base_page.css">
  </head>
  <body>
    <div class="container">
      <!-- Moving Menu -->
      <div class="header">
	<header> <a href="">
	    <h class="logo">Marpion</h>
	  </a>
	  <nav>
	    <ul>
	      <li> <a href="crew_page/crew_page.php">Crew</a> </li>
	      <li> <a href="pro_page/pro_page.php">Our Work</a> </li>
	    </ul>
	  </nav>
	</header>
      </div>
	<!-- Banniere -->
	<section class="banner">
	  <h> Marpion </h>
	  <p> EN CONSTRUCTION !!! </p>
	</section>
      <!-- Stream Video  -->
      <section class="stream">
	<div class="stream_video">
	  <iframe src="https://player.twitch.tv/?channel=properpina" frameborder="0"
		  scrolling="no">
	  </iframe>
	</div>
	<!-- Stream Chat -->
	<div class="stream_chat">
	  <iframe src="https://www.twitch.tv/properpina/chat?popout="
		  frameborder="0" scrolling="no">
	  </iframe>
	</div>
      </section>
      <!-- Schedule Tabs -->
      <section class="schedule_tabs">
	<table class="tabs">
	  <tr>
	    <th class="tabs_title"> Schedule </th>
	  </tr>
	  <tr>
	    <td> 06:00 </td>
	  </tr>
	  <tr>
	    <td> 07:00 </td>
	  </tr>
	  <tr>
	    <td> 08:00 </td>
	  </tr>
	  <tr>
	    <td> 09:00 </td>
	  </tr>
	  <tr>
	    <td> 10:00 </td>
	  </tr>
	  <tr>
	    <td> 11:00 </td>
	  </tr>
	  <tr>
	    <td> 12:00 </td>
	  </tr>
	  <tr>
	    <td> 13:00 </td>
	  </tr>
	  <tr>
	    <td> 14:00 </td>
	  </tr>
	  <tr>
	    <td> 15:00 </td>
	  </tr>
	  <tr>
	    <td> 16:00 </td>
	  </tr>
	  <tr>
	    <td> 17:00 </td>
	  </tr>
	  <tr>
	    <td> 18:00 </td>
	  </tr>
	  <tr>
	    <td> 19:00 </td>
	  </tr>
	  <tr>
	    <td> 20:00 </td>
	  </tr>
	  <tr>
	    <td> 21:00 </td>
	  </tr>
	  <tr>
	    <td> 22:00 </td>
	  </tr>
	  <tr>
	    <td> 23:00 </td>
	  </tr>
	  <tr>
	    <td> 00:00 </td>
	  </tr>
	  <tr>
	    <td> 01:00 </td>
	  </tr>
	  <tr>
	    <td> 02:00 </td>
	  </tr>
	  <tr>
	    <td> 03:00 </td>
	  </tr>
	  <tr>
	    <td> 04:00 </td>
	  </tr>
	  <tr>
	    <td> 05:00 </td>
	  </tr>
	</table>
	<table class="tabs">
	  <tr>
	    <th class="tabs_title"> Monday </th>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	</table>
	<table class="tabs">
	  <tr>
	    <th class="tabs_title"> Tuesday </th>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	</table>
	<table class="tabs">
	  <tr>
	    <th class="tabs_title"> Wednesday </th>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	</table>
	<table class="tabs">
	  <tr>
	    <th class="tabs_title"> Thursday </th>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	</table>
	<table class="tabs">
	  <tr>
	    <th class="tabs_title"> Friday </th>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	</table>
	<table class="tabs">
	  <tr>
	    <th class="tabs_title"> Saturday </th>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	</table>
	<table class="tabs">
	  <tr>
	    <th class="tabs_title"> Sunday </th>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	  <tr>
	    <td> None </td>
	  </tr>
	</table>
	  <p> EN CONSTRUCTION !!! </p>
      </section>
      <!-- Coyrights 2016 - Haneul -->
    </div>
  </body>
</html>
