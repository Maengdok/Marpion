
#ifndef BASE_COMPONENT_HPP_
#define BASE_COMPONENT_HPP_

class BaseComponent
{
    public:
        virtual ~BaseComponent();

};


#endif
