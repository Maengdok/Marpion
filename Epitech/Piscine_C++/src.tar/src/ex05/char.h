
#ifndef CHAR_H
# define CHAR_H

# include "object.h"

extern Class* Char;

#endif

