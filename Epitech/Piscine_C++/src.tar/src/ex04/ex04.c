void compareAndDivide(Object* a, Object* b)
{
    if (gt(a, b))
        printf("a > b\n");
    else if (lt(a, b))
        printf("a < b\n");
    else
        printf("a == b\n");

    printf("b / a = %s\n", str(div(b, a)));
}
