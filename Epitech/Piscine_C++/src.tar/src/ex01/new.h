
#ifndef NEW_H
# define NEW_H

#include "object.h"

void* new(Class* class);
void delete(Object* ptr);

#endif
