#include "new.h"
#include "point.h"
#include "vertex.h"

int main()
{
    Object* point = new(Point, 42, -42);
    Object* vertex = new(Vertex, 0, 1, 2);

    delete(point);
    delete(vertex);
    return 0;
}
